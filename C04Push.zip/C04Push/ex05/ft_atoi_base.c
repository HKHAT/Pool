/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/26 04:59:42 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/26 18:08:45 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

int	check(char *str)
{
	int	i;

	i = 0;
	if (str[i] == '\0' || str[1] == '\0')
		return (0);
	while (str[i])
	{
		if (str[i] == '-' || str[i] == '+')
			return (0);
		i++;
	}
	while (str[i])
	{
		while (str[i] != str[i + 1] && str[i + 1])
			i++;
		if (str[i] == str[i + 1])
			return (0);
	}
	return (1);
}

int	check_base(char c, char *str)
{
	int	i;

	i = 0;
	while (c != str[i] && str[i])
		i++;
	if (str[i] == '\0')
		return (-1);
	return (i);
}

int	con(char *str, int i, char *base)
{
	int	res;
	int	blen;

	res = 0;
	blen = ft_strlen(base);
	while (str[i])
	{
		if (check_base(str[i], base) == -1)
		{
			break ;
		}
		res = (res * blen) + check_base(str[i], base);
		i++;
	}
	return (res);
}

int	ft_atoi_base(char *str, char *base)
{
	int	i;
	int	r;
	int	s;

	r = 0;
	s = 1;
	i = 0;
	if (!str || !base)
		return (0);
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			s *= -1;
		i++;
	}
	if (!check(base))
		return (0);
	r = con(str, i, base);
	return (r * s);
}
