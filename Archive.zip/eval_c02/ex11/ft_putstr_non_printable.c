/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 16:05:53 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/21 17:43:48 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr_non_printable(char *str)
{
	unsigned int	i;
	unsigned char	a;

	i = 0;
	while (str[i])
	{
		if (str[i] < 32 || str[i] == 127)
		{
			write (1, "\\", 1);
			a = str[i];
			write (1, &"0123456789abcdef"[a / 16], 1);
			write(1, &"0123456789abcdef"[a % 16], 1);
		}
		else
		{
			write (1, &str[i], 1);
		}
		i++;
	}
}
