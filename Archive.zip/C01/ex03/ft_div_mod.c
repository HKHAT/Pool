/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/18 22:02:12 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/21 17:14:55 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
#include <stdio.h>
int main()
{
	int n,m;
	int c,d;
	n = 10;
	m = 5;
	ft_div_mod(n,m,&d,&c);
	printf("c == %d\n d == %d",d,c);

}
