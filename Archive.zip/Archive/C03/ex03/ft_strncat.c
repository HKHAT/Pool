/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/20 20:44:25 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/23 06:00:08 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	int				i;
	unsigned int	len;

	len = 0;
	i = 0;
	while (dest[i])
	{
		i++;
	}
	while (src[i] && len < nb)
	{
		dest[i + len] = src[len];
		len++;
	}
	dest[i + len] = '\0';
	return (dest);
}
