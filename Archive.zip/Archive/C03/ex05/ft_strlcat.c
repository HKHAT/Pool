/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/22 02:45:30 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/23 08:51:58 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	len;
	unsigned int	sl;
	unsigned int	dl;

	i = 0;
	len = 0;
	sl = ft_strlen(src);
	while (dest[i])
	{
		i++;
	}
	dl = i;
	if (size == 0 || size <= dl)
		return (sl + size);
	while (src[len] && len < size - dl - 1)
	{
		dest[i] = src[len];
		len++;
		i++;
	}
	dest[i] = '\0';
	return (dl + sl);
}
