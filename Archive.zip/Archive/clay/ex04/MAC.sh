#!/bin/sh
ifconfig |grep -o ..:..:..:..:..:..
