git log ls-files --exclude-standard --others --ignored
