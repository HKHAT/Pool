/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elchakir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/18 22:19:13 by elchakir          #+#    #+#             */
/*   Updated: 2023/08/19 03:35:42 by elchakir         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_rev_int_tab(int *tab, int size)
{
	int	f;
	int	l;
	int	tmp;

	f = 0;
	l = size -1;
	while (f < l)
	{
		tmp = tab[f];
		tab[f] = tab[l];
		tab[l] = tmp;
		f++;
		l--;
	}
}
